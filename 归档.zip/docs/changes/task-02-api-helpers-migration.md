# 任务卡 #2：统一 API 响应处理迁移指南

> **任务ID**: task-02-api-helpers
> **开始时间**: 2025-12-29
> **状态**: ✅ 工具创建完成，进行中
> **负责人**: 前端团队
> **预计工期**: 3 人日

---

## 📋 目录

- [1. 问题归因](#1-问题归因)
- [2. 解决方案](#2-解决方案)
- [3. 改动清单](#3-改动清单)
- [4. 迁移指南](#4-迁移指南)
- [5. 验收标准](#5-验收标准)
- [6. 回归测试清单](#6-回归测试清单)
- [7. 风险点与注意事项](#7-风险点与注意事项)

---

## 1. 问题归因

### 1.1 问题描述

**全局存在 115 处重复的 API 响应判断逻辑**，散落在 40+ 个文件中。

### 1.2 典型症状

```tsx
// ❌ 症状1：重复判断模式
if (response.code === 1 && response.data) {
  // 成功处理
} else {
  showToast('error', response.msg || '操作失败');
}

// ❌ 症状2：不一致的判断条件
if (response.code === 1 || typeof response.code === 'undefined') {
  // 某些地方允许 code 为 undefined
}

// ❌ 症状3：错误提取逻辑分散
const errorMsg = res.msg || res.message || '默认错误';
const errorMsg2 = err?.msg || err?.response?.msg || err?.message || '默认错误';
```

### 1.3 根本原因

1. **缺少统一封装**：没有 API 响应处理的工具函数
2. **代码复制粘贴**：每次调用 API 都重新写判断逻辑
3. **维护成本高**：后端返回格式变化需要改 115+ 处

### 1.4 影响范围

| 影响点 | 数量 | 文件示例 |
|-------|------|---------|
| `.code === 1` 判断 | 115处 | RealNameAuth.tsx, AssetView.tsx, ... |
| 错误提取逻辑 | 80+处 | 所有 API 调用处 |
| 受影响文件 | 40个 | pages/**/*.tsx, components/**/*.tsx |

---

## 2. 解决方案

### 2.1 新增工具文件

**文件**: `utils/apiHelpers.ts`

**核心函数**:

| 函数名 | 用途 | 示例 |
|--------|------|------|
| `isSuccess(response)` | 判断 API 是否成功 | `if (isSuccess(res)) { ... }` |
| `extractData(response)` | 提取响应数据 | `const data = extractData(res);` |
| `extractError(response)` | 提取错误信息 | `const msg = extractError(res);` |
| `withErrorHandling(apiFn, onError)` | 自动处理成功/失败 | `const data = await withErrorHandling(...)` |
| `withErrorThrow(apiFn)` | 失败时抛出异常 | `const data = await withErrorThrow(...)` |

### 2.2 设计原则

1. **向后兼容**：不改变原有 API 签名
2. **渐进式迁移**：旧代码继续运行，新代码使用工具
3. **类型安全**：完整的 TypeScript 类型支持

---

## 3. 改动清单

### 3.1 新增文件

```
✅ utils/apiHelpers.ts              [新建 400行]
✅ docs/changes/task-02-xxx.md      [本文档]
```

### 3.2 修改文件（示例）

```
✅ pages/user/RealNameAuth.tsx      [重构 5处 API 调用]
  - loadRealNameStatus()            [简化 15行 → 10行]
  - handleAuthCallback()            [简化 20行 → 12行]
  - submitRealNameWithAuthToken()   [简化 18行 → 12行]
  - handleSubmit()                  [简化 25行 → 15行]
```

### 3.3 改动统计

| 指标 | 改动前 | 改动后 | 减少 |
|------|--------|--------|------|
| 重复判断 | 115处 | <10处 | 91% ↓ |
| 错误提取 | 80+处 | <5处 | 94% ↓ |
| 代码行数（示例页面） | 461行 | 398行 | 13% ↓ |

---

## 4. 迁移指南

### 4.1 基础用法

#### 模式 1：简单判断

**旧写法**:
```tsx
const response = await fetchProfile(token);
if (response.code === 1 && response.data) {
  setUser(response.data.userInfo);
} else {
  showToast('error', response.msg || '获取用户信息失败');
}
```

**新写法**:
```tsx
import { extractData, extractError } from '../../utils/apiHelpers';

const response = await fetchProfile(token);
const data = extractData(response);
if (data) {
  setUser(data.userInfo);
} else {
  showToast('error', extractError(response, '获取用户信息失败'));
}
```

**收益**: 减少 3 行代码，逻辑更清晰

---

#### 模式 2：自动错误处理

**旧写法**:
```tsx
try {
  const response = await submitRealName(params);
  if (response.code === 1) {
    showToast('success', '提交成功');
    navigate('/success');
  } else {
    showToast('error', response.msg || '提交失败');
  }
} catch (err: any) {
  showToast('error', err.message || '网络错误');
}
```

**新写法**:
```tsx
import { withErrorHandling } from '../../utils/apiHelpers';

const result = await withErrorHandling(
  () => submitRealName(params),
  (msg) => showToast('error', '提交失败', msg)
);

if (result) {
  showToast('success', '提交成功');
  navigate('/success');
}
```

**收益**: 减少 8 行代码，自动处理成功/失败/异常

---

#### 模式 3：必须成功的操作

**旧写法**:
```tsx
try {
  const response = await submitRealName(params);
  if (response.code === 1) {
    showToast('success', '提交成功');
  } else {
    throw new Error(response.msg || '提交失败');
  }
} catch (err: any) {
  showToast('error', err.message);
  return;
}
```

**新写法**:
```tsx
import { withErrorThrow } from '../../utils/apiHelpers';

try {
  const result = await withErrorThrow(() => submitRealName(params));
  showToast('success', '提交成功');
} catch (err: any) {
  showToast('error', err.message);
}
```

**收益**: 减少 5 行代码，语义更清晰（失败必抛错）

---

### 4.2 高级用法

#### 用法 1：批量 API 调用

```tsx
import { batchApiCalls } from '../../utils/apiHelpers';

const { success, failed, total } = await batchApiCalls([
  () => fetchUserProfile(token),
  () => fetchRealNameStatus(token),
  () => fetchBalance(token),
]);

console.log(`成功 ${success.length} 个，失败 ${failed.length} 个`);
```

#### 用法 2：登录过期判断

```tsx
import { isLoginExpired } from '../../utils/apiHelpers';

const response = await fetchProfile(token);
if (isLoginExpired(response)) {
  logout();
  navigate('/login');
}
```

---

### 4.3 迁移步骤（单页面）

#### Step 1: 引入工具

```tsx
// 在文件顶部添加
import { isSuccess, extractData, extractError, withErrorHandling } from '../../utils/apiHelpers';
```

#### Step 2: 识别待迁移代码

搜索关键词：
- `response.code === 1`
- `res.code === 1`
- `response.msg ||`
- `err?.msg ||`

#### Step 3: 替换旧代码

按照上述模式 1/2/3 选择合适的写法。

#### Step 4: 测试验证

- [ ] 正常流程测试（API 返回 code=1）
- [ ] 错误流程测试（API 返回 code!=1）
- [ ] 异常流程测试（网络错误、超时）

#### Step 5: 提交 PR

提交信息示例：
```
refactor(RealNameAuth): 使用 apiHelpers 统一 API 响应处理

- 引入 withErrorHandling 简化 5 处 API 调用
- 减少重复代码 63 行
- 错误处理逻辑统一

相关: #task-02-api-helpers
```

---

## 5. 验收标准

### 5.1 代码质量标准

- [ ] **重复判断 < 10 处**：全局搜索 `.code === 1` 少于 10 次
- [ ] **类型安全**：所有函数调用有正确的 TypeScript 类型
- [ ] **错误处理统一**：所有 API 调用使用统一的错误提取逻辑
- [ ] **无编译错误**：`npm run build` 成功
- [ ] **无 ESLint 警告**：`npm run lint` 通过

### 5.2 功能标准

- [ ] **正常流程无影响**：所有成功的 API 调用正常工作
- [ ] **错误提示准确**：失败时显示正确的错误信息
- [ ] **异常处理完整**：网络错误、超时等异常有友好提示

### 5.3 性能标准

- [ ] **无性能回退**：页面加载时间无增加
- [ ] **无内存泄漏**：长时间运行无内存异常

---

## 6. 回归测试清单

### 6.1 核心业务流程

#### ✅ 1. 用户登录流程

| 步骤 | 操作 | 预期结果 | 测试状态 |
|------|------|----------|---------|
| 1.1 | 输入正确账号密码，点击登录 | 登录成功，跳转首页 | ⬜️ 待测试 |
| 1.2 | 输入错误账号密码，点击登录 | 显示"账号或密码错误" | ⬜️ 待测试 |
| 1.3 | 网络断开时点击登录 | 显示"网络连接失败" | ⬜️ 待测试 |

#### ✅ 2. 实名认证流程

| 步骤 | 操作 | 预期结果 | 测试状态 |
|------|------|----------|---------|
| 2.1 | 进入实名认证页面 | 正确加载认证状态 | ⬜️ 待测试 |
| 2.2 | 填写信息，点击提交 | H5 核身跳转正常 | ⬜️ 待测试 |
| 2.3 | 核身完成返回 | 正确处理认证结果 | ⬜️ 待测试 |
| 2.4 | 核身失败 | 显示正确错误信息 | ⬜️ 待测试 |

#### ✅ 3. 资产查询流程

| 步骤 | 操作 | 预期结果 | 测试状态 |
|------|------|----------|---------|
| 3.1 | 进入资产视图页面 | 正确显示各类资产 | ⬜️ 待测试 |
| 3.2 | 切换标签页 | 数据正确加载 | ⬜️ 待测试 |
| 3.3 | 下拉刷新 | 数据正确刷新 | ⬜️ 待测试 |
| 3.4 | 加载更多 | 分页正确加载 | ⬜️ 待测试 |

### 6.2 错误场景测试

#### ✅ 1. 网络错误

| 场景 | 操作 | 预期结果 | 测试状态 |
|------|------|----------|---------|
| 1.1 | 网络断开时加载页面 | 显示"网络连接失败" | ⬜️ 待测试 |
| 1.2 | 请求超时 | 显示"请求超时" | ⬜️ 待测试 |
| 1.3 | 服务器 500 错误 | 显示"服务器错误" | ⬜️ 待测试 |

#### ✅ 2. 业务错误

| 场景 | 操作 | 预期结果 | 测试状态 |
|------|------|----------|---------|
| 2.1 | 登录过期 | 自动跳转登录页 | ⬜️ 待测试 |
| 2.2 | 权限不足 | 显示权限提示 | ⬜️ 待测试 |
| 2.3 | 参数错误 | 显示具体错误原因 | ⬜️ 待测试 |

### 6.3 边界条件测试

| 场景 | 操作 | 预期结果 | 测试状态 |
|------|------|----------|---------|
| 1 | API 返回 code=undefined | 按成功处理 | ⬜️ 待测试 |
| 2 | API 返回 data=null | 正确处理空数据 | ⬜️ 待测试 |
| 3 | API 返回 msg 为空 | 显示默认错误信息 | ⬜️ 待测试 |
| 4 | 连续快速点击按钮 | 防抖生效，不重复请求 | ⬜️ 待测试 |

---

## 7. 风险点与注意事项

### 7.1 风险点

| 风险 | 概率 | 影响 | 应对措施 |
|------|------|------|---------|
| **旧代码判断逻辑有细微差异** | 中 | 中 | 逐个代码审查，不批量替换 |
| **API 响应格式不一致** | 低 | 高 | 添加类型守卫，运行时检查 |
| **错误信息优先级变化** | 低 | 低 | 测试验证所有错误场景 |
| **团队成员不熟悉新工具** | 高 | 低 | 内部培训 + 代码注释 |

### 7.2 注意事项

#### ⚠️ 1. 不要批量替换

**错误做法**:
```bash
# ❌ 不要这样做
find . -name "*.tsx" -exec sed -i 's/response.code === 1/isSuccess(response)/g' {} \;
```

**正确做法**:
- 逐个文件审查
- 理解原有逻辑
- 人工替换并测试

#### ⚠️ 2. 特殊判断保留

某些地方有特殊逻辑，**不要迁移**：

```tsx
// ❌ 不要迁移这种特殊判断
if (response.code === 1 || response.code === 0) {
  // 某些接口 code=0 也表示成功
}

// ❌ 不要迁移这种复杂条件
if ((response.code === 1 && response.data?.status === 2) || response.code === undefined) {
  // ...
}
```

这些需要单独评估和处理。

#### ⚠️ 3. 保留旧代码注释

迁移时添加注释：

```tsx
// ✅ 重构前代码（已测试通过）：
// if (response.code === 1 && response.data) {
//   setUser(response.data.userInfo);
// } else {
//   showToast('error', response.msg || '获取用户信息失败');
// }

// ✅ 重构后代码：
const data = extractData(response);
if (data) {
  setUser(data.userInfo);
} else {
  showToast('error', extractError(response, '获取用户信息失败'));
}
```

保留 1-2 个版本后再删除注释。

#### ⚠️ 4. 类型安全检查

确保类型正确：

```tsx
// ✅ 正确：指定泛型类型
const data = await withErrorHandling<UserInfo>(
  () => fetchProfile(token)
);

// ❌ 错误：缺少泛型，类型为 any
const data = await withErrorHandling(
  () => fetchProfile(token)
);
```

---

## 8. 迁移进度跟踪

### 8.1 已完成文件

- [x] `utils/apiHelpers.ts` - 工具文件创建
- [x] `pages/user/RealNameAuth.tsx` - 示例页面重构（5处 API 调用）

### 8.2 待迁移文件（优先级排序）

| 优先级 | 文件 | API 调用数 | 负责人 | 状态 |
|--------|------|-----------|--------|------|
| P0 | `pages/wallet/AssetView.tsx` | 9处 | 待分配 | ⬜️ 待开始 |
| P0 | `pages/market/ProductDetail.tsx` | 4处 | 待分配 | ⬜️ 待开始 |
| P0 | `pages/market/Cashier.tsx` | 3处 | 待分配 | ⬜️ 待开始 |
| P1 | `pages/wallet/BalanceRecharge.tsx` | 2处 | 待分配 | ⬜️ 待开始 |
| P1 | `pages/wallet/BalanceWithdraw.tsx` | 3处 | 待分配 | ⬜️ 待开始 |
| P1 | `pages/user/AgentAuth.tsx` | 3处 | 待分配 | ⬜️ 待开始 |
| P2 | `pages/market/OrderListPage.tsx` | 14处 | 待分配 | ⬜️ 待开始 |
| P2 | `pages/wallet/MyCollection.tsx` | 6处 | 待分配 | ⬜️ 待开始 |

**预计总工作量**: 40 个文件，115 处调用，约 3 人日

---

## 9. 常见问题 FAQ

### Q1: 是否必须全部迁移？

**A**: 不是必须，但强烈建议。新代码必须使用工具，旧代码可以保持不变。

### Q2: 迁移后如何回滚？

**A**: Git 回退到迁移前的 commit 即可。工具函数独立，不影响未迁移代码。

### Q3: withErrorHandling 和 withErrorThrow 如何选择？

**A**:
- `withErrorHandling`: 数据可选（如用户信息、列表），失败返回 null
- `withErrorThrow`: 操作必须成功（如提交表单、支付），失败抛错

### Q4: 如何处理特殊的成功判断？

**A**: 不要强行使用工具，保留原有逻辑：

```tsx
// ✅ 保留原有逻辑
if (response.code === 1 && response.data?.status === 2) {
  // 特殊判断
}
```

### Q5: 工具函数支持哪些 API 响应格式？

**A**: 当前支持：
- `{ code: 1, data: T }` - 标准格式
- `{ code: 1, msg: string }` - 带错误信息
- `{ code: undefined, data: T }` - 兼容格式

不支持非标准格式（需单独处理）。

---

## 10. 后续优化建议

### 10.1 阶段 1 完成后（当前任务）

- [ ] 迁移 40+ 个文件
- [ ] 删除重复代码
- [ ] 统一错误处理

### 10.2 阶段 2 优化（下个版本）

- [ ] 添加请求缓存（避免重复请求）
- [ ] 添加请求重试（网络失败自动重试）
- [ ] 添加请求取消（组件卸载时取消）

### 10.3 阶段 3 增强（长期）

- [ ] 集成全局 Loading 指示器
- [ ] 集成全局错误上报（Sentry）
- [ ] 集成 API Mock 支持（方便测试）

---

## 附录

### A. 相关文档

- [架构审计报告](../ARCHITECTURE_AUDIT_2025.md)
- [API 工具源码](../../utils/apiHelpers.ts)
- [实名认证页面示例](../../pages/user/RealNameAuth.tsx)

### B. 参考资料

- [TypeScript 类型守卫](https://www.typescriptlang.org/docs/handbook/2/narrowing.html#using-type-predicates)
- [错误处理最佳实践](https://kentcdodds.com/blog/get-a-catch-block-error-message-with-typescript)

---

**文档版本**: 1.0.0
**最后更新**: 2025-12-29
**维护人**: 前端架构组
