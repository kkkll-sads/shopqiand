# Cultural Asset Trader (数权中心)


一个综合性的移动端优先的数字文化资产交易 Web 应用程序，具有艺术品展示、商城、新闻资讯和订单管理等功能。

> ⚠️ **交接注意**: 本项目于 2025-12-06 进行了架构重构，详情请查阅 [项目重构日志 (REFACTORING_LOG.md)](./REFACTORING_LOG.md)。

## 📱 项目概览

本项目是一个基于 React 的 Web 应用程序，旨在模拟移动端 App 体验（“数权中心”）。它促进了数字文化资产的交易，包括绘画、书法和其他艺术作品。

### 核心功能

*   **首页 (Home)**:
    *   支持触摸滑动的自动播放轮播图。
    *   垂直滚动的平台新闻快讯。
    *   快速访问子模块（关于我们、资讯、艺术家、藏品）。
    *   专属“交易专区”入口。
    *   艺术家展示预览。
*   **商城 (Market)**:
    *   商品搜索和分类（艺术品、非遗等）。
    *   排序选项（价格、销量、最新）。
    *   带有规格选择面板的商品详情页。
*   **交易专区 (Trading Zone)**:
    *   正在进行和即将开始的交易场次的可视化仪表盘。
*   **资讯中心 (News)**:
    *   “平台公告”和“平台动态”的分页视图。
    *   阅读状态追踪（红点指示器）。
    *   已读项目的本地存储持久化。
    *   “清除所有未读”功能。
*   **订单中心 (Orders)**:
    *   分类订单管理（商品、交易、提货、积分）。
    *   不同状态的分页订单列表。
*   **我的 (Profile)**:
    *   带有资产概览的用户仪表盘。
    *   详细的资产视图（余额、服务费、积分）。
    *   **用户状态徽章**：区分新用户、普通用户和交易用户的独特图标。
    *   **代理徽章**：已验证代理商的专属徽章。
*   **子页面**:
    *   **艺术家详情**: 简介、个人资料和作品库。
    *   **艺术家/藏品展示**: 用于浏览内容的网格视图。
    *   **关于我们**: 平台介绍。
    *   **实名认证**: 用户身份验证流程。
    *   **代理商申请**: 代理商入驻申请流程。

## 🛠 技术栈

*   **框架**: React 18+
*   **样式**: Tailwind CSS
*   **图标**: Lucide React
*   **语言**: TypeScript
*   **构建工具**: 标准 ES Modules (模拟环境)

## 📂 项目结构

```
/
├── index.html              # 带有全局样式的入口 HTML
├── index.tsx               # App 入口点
├── App.tsx                 # 主路由和状态管理
├── types.ts                # TypeScript 接口定义
├── constants.ts            # 模拟数据 (艺术家, 商品, 资讯, 订单)
├── REFACTORING_LOG.md      # 项目重构日志 (2025-12-06)
├── components/             # 可复用 UI 组件
│   ├── common/             # 通用基础组件 (PageContainer, Loading, etc.)
│   │   ├── PageContainer.tsx
│   │   ├── LoadingSpinner.tsx
│   │   ├── EmptyState.tsx
│   │   └── ...
│   ├── BottomNav.tsx       # 底部主导航栏
│   └── ...
├── services/               # API 服务层 (模块化)
│   ├── index.ts            # 服务统一导出
│   ├── auth.ts             # 认证服务
│   ├── user.ts             # 用户服务
│   ├── wallet.ts           # 钱包服务
│   ├── market.ts           # 商城服务
│   └── Networking.ts       # 核心请求封装
└── pages/                  # 应用程序屏幕 (按模块归类)
    ├── auth/               # 认证模块 (Login, Register...)
    ├── user/               # 用户中心 (Profile, Settings, Address...)
    ├── cms/                # 内容模块 (Home, News, HelpCenter...)
    ├── market/             # 交易模块 (Market, ProductDetail...)
    └── wallet/             # 资金模块 (Recharge, Withdraw...)
```

## 🚀 开发说明

*   **移动端优先**: UI 针对移动端视口进行了优化（建议桌面端测试时宽度约为 `max-width: 480px`）。
*   **无滚动条**: 全局 CSS 隐藏了滚动条以模拟原生 App 的感觉。
*   **模拟数据**: 所有数据目前都是静态的，位于 `constants.ts` 中。
*   **路由**: 通过 `App.tsx` 中的条件渲染实现（SPA 行为），而不是使用 `react-router-dom` 等库，以保持环境轻量和独立。

## 🎨 设计系统

*   **主色调**: 橙色 (`orange-500` / `orange-600`)
*   **背景**: 头部使用浅橙色渐变 (`from-[#FFD6A5] to-gray-50`)，内容区域为白色。
*   **排版**: 无衬线字体，专为小屏幕易读性定制。

---

## 💻 安装与运行 (Installation)

### 环境要求
*   Node.js >= 18.0.0
*   npm >= 9.0.0

### 本地开发
1.  **克隆项目**:
    ```bash
    git clone https://github.com/xiaojieyahuhu/Cultural.git
    cd Cultural
    ```

2.  **安装依赖**:
    ```bash
    npm install
    ```

3.  **启动开发服务器**:
    ```bash
    npm run dev
    ```
    访问: `http://localhost:5173`

---

## 🌐 Ubuntu 部署教程 (Ubuntu Deployment)

本教程假设您使用的是 Ubuntu 20.04/22.04 服务器。

### 1. 基础环境配置
更新系统并安装 Node.js (推荐使用 NVM):
```bash
sudo apt update
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.5/install.sh | bash
source ~/.bashrc
nvm install 20
node -v # 验证安装
```

### 2. 构建项目
在服务器上拉取代码并构建生产版本:
```bash
# 进入项目目录
npm install
npm run build
```
构建完成后会生成 `dist` 目录，这是需要部署的静态文件资源。

### 3. 使用 Nginx 部署 (推荐)
安装 Nginx 并配置反向代理:

```bash
sudo apt install nginx
```

创建 Nginx 配置文件 `/etc/nginx/sites-available/cultural`:
```nginx
server {
    listen 80;
    server_name your_server_ip_or_domain;

    root /path/to/your/project/Cultural/dist; # 修改为你的实际 dist 路径
    index index.html;

    location / {
        try_files $uri $uri/ /index.html; # 支持 SPA 路由
    }

    # API 代理
    location /api/ {
        proxy_pass http://18.162.70.209:3005/index.php/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # 静态资源代理
    location ~ ^/(uploads|static|storage)/ {
        proxy_pass http://18.162.70.209:3005;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

启用配置并重启 Nginx:
```bash
sudo ln -s /etc/nginx/sites-available/cultural /etc/nginx/sites-enabled/
sudo nginx -t # 检查语法
sudo systemctl restart nginx
```

---

## 🔌 局域网/公网 IP 直连访问教程

如果您不使用 Nginx，想直接通过 `http://IP:端口` 访问：

### 方案 A: 临时开发访问 (Dev Mode)
启动时绑定所有网卡 (0.0.0.0):
```bash
npm run dev -- --host 0.0.0.0
```
*   **访问地址**: `http://YOUR_SERVER_IP:5173`
*   **注意**: 请确保防火墙放行 5173 端口。

### 方案 B: 生产环境直连 (Production Preview)
如果不想配 Nginx，可以使用 `vite preview` 或 `serve` 工具进行简易部署:

1.  **构建**:
    ```bash
    npm run build
    ```

2.  **运行 Preview (绑定公网)**:
    ```bash
    npm run preview -- --host 0.0.0.0 --port 5173
    ```

3.  **防火墙设置 (重要)**:
    如果无法访问，请检查 Ubuntu 防火墙 (UFW):
    ```bash
    sudo ufw allow 5173/tcp
    ```
    如果是云服务器 (AWS/阿里云/腾讯云)，请务必在**安全组**中放行 5173 端口。
