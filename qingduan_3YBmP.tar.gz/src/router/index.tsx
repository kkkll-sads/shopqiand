import { createBrowserRouter } from 'react-router-dom';
import routes from './routes';

// 与 Vite base 一致，部署在子路径时刷新才能正确匹配路由（避免误入其他页如客服）
const base = typeof import.meta.env.BASE_URL === 'string' ? import.meta.env.BASE_URL : '/';
const basename =
  base && base !== '/' ? (base.endsWith('/') ? base.slice(0, -1) : base) : undefined;

export const router = createBrowserRouter(routes, { basename });

export default router;
