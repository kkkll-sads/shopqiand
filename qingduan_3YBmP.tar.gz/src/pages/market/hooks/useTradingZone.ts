/**
 * useTradingZone - 交易区逻辑 Hook
 */
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import {
  fetchCollectionSessions,
  fetchCollectionItemsBySession,
  CollectionSessionItem,
  CollectionItem,
  fetchAnnouncements,
  AnnouncementItem,
} from '@/services';
import { isSuccess } from '@/utils/apiHelpers';
import { debugLog, errorLog } from '@/utils/logger';

export interface TradingSession {
  id: string;
  title: string;
  image: string;
  startTime: string;
  endTime: string;
  isActive?: boolean;
}

export interface TradingDisplayItem extends CollectionItem {
  source?: 'collection' | 'consignment' | 'mixed';
  consignment_id?: number;
  displayKey: string;
  hasStockInfo?: boolean;
  package_name?: string;
  package_id?: number;
  official_stock?: number;
  consignment_count?: number;
  total_available?: number;
  min_price?: number | string;
  max_price?: number | string;
  price_range?: string;
  consignment_list?: Array<{
    consignment_id: number;
    price: number;
    seller_id: number;
  }>;
}

interface UseTradingZoneParams {
  initialSessionId?: string;
  initialSessionTitle?: string;
  initialSessionStartTime?: string;
  initialSessionEndTime?: string;
}

interface TradingItemWithMeta extends CollectionItem {
  consignment_count?: number;
  consignment_list?: Array<{
    consignment_id: number;
    price: number;
    seller_id: number;
  }>;
  official_stock?: number;
  min_price?: number;
  package_id?: number;
  zone_id?: number | string;
}

interface SessionWithActiveFlag extends CollectionSessionItem {
  is_active?: boolean | number;
}

export function useTradingZone({
  initialSessionId,
  initialSessionTitle,
  initialSessionStartTime,
  initialSessionEndTime,
}: UseTradingZoneParams) {
  const [sessions, setSessions] = useState<TradingSession[]>([]);
  const [selectedSession, setSelectedSession] = useState<TradingSession | null>(null);
  const [tradingItems, setTradingItems] = useState<TradingDisplayItem[]>([]);
  const [activePriceZone, setActivePriceZone] = useState<string>('all');
  const [now, setNow] = useState(new Date());
  const [navigating, setNavigating] = useState(false);

  // Loading states
  const [loading, setLoading] = useState(false);
  const [itemsLoading, setItemsLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [hasMore, setHasMore] = useState(false);

  // Error states
  const [sessionErrorMessage, setSessionErrorMessage] = useState<string | null>(null);
  const [itemsErrorMessage, setItemsErrorMessage] = useState<string | null>(null);

  const hasSessionError = !!sessionErrorMessage;
  const hasItemsError = !!itemsErrorMessage;

  // Refs for tracking loading state
  const loadingSessionRef = useRef<string | null>(null);
  const sessionsLoadedRef = useRef(false);
  const sessionStatusesRef = useRef<Map<string, { status: 'active' | 'waiting' | 'ended'; target: Date | null }>>(new Map());
  const currentPageRef = useRef(1);
  const currentSessionIdRef = useRef<string | null>(null);

  const PAGE_LIMIT = 10;

  // Map raw API item to display item
  const mapToDisplayItem = useCallback((rawItem: CollectionItem): TradingDisplayItem => {
    const item = rawItem as TradingItemWithMeta;
    const hasConsignment = item.consignment_count > 0 || (item.consignment_list && item.consignment_list.length > 0);
    const hasOfficial = item.official_stock > 0 || item.stock > 0;

    let source: 'collection' | 'consignment' | 'mixed' = 'collection';
    if (hasConsignment && hasOfficial) {
      source = 'mixed';
    } else if (hasConsignment) {
      source = 'consignment';
    }

    const displayPrice = Number(item.price || item.min_price || 0);
    const totalAvailable = item.total_available ?? ((item.official_stock || 0) + (item.consignment_count || 0));

    return {
      ...item,
      price: displayPrice,
      stock: totalAvailable,
      official_stock: item.official_stock || item.stock || 0,
      consignment_count: item.consignment_count || 0,
      total_available: totalAvailable,
      package_name: item.package_name || item.title,
      title: item.package_name || item.title || `${item.price_zone}元区`,
      package_id: item.package_id,
      displayKey: `pkg-${item.zone_id || item.id}-${item.package_name || item.id}`,
      source,
      hasStockInfo: totalAvailable > 0
    };
  }, []);

  // Load session items (first page)
  const loadSessionItems = useCallback(async (session: TradingSession) => {
    if (loadingSessionRef.current === session.id) {
      debugLog('useTradingZone', 'Session already loading, skipping', session.id);
      return;
    }

    try {
      loadingSessionRef.current = session.id;
      setItemsLoading(true);
      setItemsErrorMessage(null);
      currentPageRef.current = 1;
      currentSessionIdRef.current = session.id;

      const response = await fetchCollectionItemsBySession(session.id, { page: 1, limit: PAGE_LIMIT });

      if (isSuccess(response) && response.data?.list) {
        const allItems = response.data.list.map(mapToDisplayItem);
        const total = response.data.total || 0;

        if (allItems.length > 0) {
          setTradingItems(allItems);
          setHasMore(allItems.length < total);
        } else {
          setTradingItems([]);
          setHasMore(false);
          setItemsErrorMessage('暂无上链资产');
        }
      } else {
        setTradingItems([]);
        setHasMore(false);
        setItemsErrorMessage('暂无上链资产');
      }

      setSelectedSession(session);
    } catch (err: unknown) {
      errorLog('useTradingZone', '加载专场商品失败:', err);
      setItemsErrorMessage('数据同步延迟，请重试');
      setHasMore(false);
      setSelectedSession(session);
    } finally {
      setItemsLoading(false);
      loadingSessionRef.current = null;
    }
  }, [mapToDisplayItem]);

  // Load more items (next page)
  const loadMoreItems = useCallback(async () => {
    if (loadingMore || !hasMore || !currentSessionIdRef.current) return;

    try {
      setLoadingMore(true);
      const nextPage = currentPageRef.current + 1;

      const response = await fetchCollectionItemsBySession(currentSessionIdRef.current, {
        page: nextPage,
        limit: PAGE_LIMIT,
      });

      if (isSuccess(response) && response.data?.list) {
        const newItems = response.data.list.map(mapToDisplayItem);
        const total = response.data.total || 0;

        if (newItems.length > 0) {
          currentPageRef.current = nextPage;
          setTradingItems(prev => {
            const updated = [...prev, ...newItems];
            setHasMore(updated.length < total);
            return updated;
          });
        } else {
          setHasMore(false);
        }
      } else {
        setHasMore(false);
      }
    } catch (err: unknown) {
      errorLog('useTradingZone', '加载更多商品失败:', err);
    } finally {
      setLoadingMore(false);
    }
  }, [loadingMore, hasMore, mapToDisplayItem]);

  // Load sessions - only run once
  useEffect(() => {
    if (sessionsLoadedRef.current) return;

    const loadSessions = async () => {
      sessionsLoadedRef.current = true;
      setLoading(true);
      setSessionErrorMessage(null);

      try {
        const response = await fetchCollectionSessions();
        if (isSuccess(response) && response.data?.list) {
          const sessionList: TradingSession[] = response.data.list.map((rawItem: CollectionSessionItem) => {
            const item = rawItem as SessionWithActiveFlag;
            return {
              ...item,
              id: String(item.id),
              title: item.title,
              image: item.image,
              startTime: item.start_time,
              endTime: item.end_time,
              isActive: Boolean(item.is_active),
            };
          });
          setSessions(sessionList);

          if (initialSessionId) {
            const matchedSession = sessionList.find(s => s.id === initialSessionId);
            if (matchedSession) {
              loadSessionItems(matchedSession);
            } else if (initialSessionTitle) {
              const tempSession: TradingSession = {
                id: initialSessionId,
                title: initialSessionTitle,
                image: '',
                startTime: initialSessionStartTime || '',
                endTime: initialSessionEndTime || '',
              };
              loadSessionItems(tempSession);
            }
          }
        } else {
          setSessionErrorMessage('获取数据资产池失败');
        }
      } catch (err: unknown) {
        errorLog('useTradingZone', '加载专场列表失败:', err);
        setSessionErrorMessage('网络连接异常');
      } finally {
        setLoading(false);
      }
    };

    loadSessions();
  }, [initialSessionId, initialSessionTitle, initialSessionStartTime, initialSessionEndTime, loadSessionItems]);

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setNow(new Date());
      sessionStatusesRef.current.clear();
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Get session status
  const getSessionStatus = useCallback((session: TradingSession) => {
    const cached = sessionStatusesRef.current.get(session.id);
    if (cached) {
      return cached;
    }

    const [startH, startM] = session.startTime.split(':').map(Number);
    const [endH, endM] = session.endTime.split(':').map(Number);
    const startDate = new Date(now); startDate.setHours(startH, startM, 0, 0);
    const endDate = new Date(now); endDate.setHours(endH, endM, 0, 0);

    let status: 'active' | 'waiting' | 'ended';
    let target: Date | null = null;

    if (now >= endDate) {
      status = 'ended';
    } else if (session.isActive || (now >= startDate && now < endDate)) {
      status = 'active';
      target = endDate;
    } else if (now < startDate) {
      status = 'waiting';
      target = startDate;
    } else {
      status = 'ended';
    }

    const result = { status, target };
    sessionStatusesRef.current.set(session.id, result);
    return result;
  }, [now]);

  // Get price zones from items
  const priceZones = useMemo(() => {
    return ['all', ...Array.from(new Set(
      tradingItems
        .map(item => item.price_zone)
        .filter(zone => zone)
    ))] as string[];
  }, [tradingItems]);

  return {
    sessions,
    selectedSession,
    tradingItems,
    activePriceZone,
    loading,
    itemsLoading,
    loadingMore,
    hasMore,
    hasSessionError,
    sessionErrorMessage,
    hasItemsError,
    itemsErrorMessage,
    navigating,
    priceZones,
    setSelectedSession,
    setTradingItems,
    setActivePriceZone,
    setNavigating,
    loadSessionItems,
    loadMoreItems,
    getSessionStatus,
  };
}
