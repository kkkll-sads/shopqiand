System.register(["./index-legacy-BAWxtBaz.js"],function(e,t){"use strict";var r;return{setters:[e=>{r=e.x}],execute:function(){
/**
       * @license lucide-react v0.546.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("R",r("rotate-ccw",[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]]))}}});
