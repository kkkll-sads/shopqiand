System.register(["./index-legacy-BAWxtBaz.js"],function(e,c){"use strict";var t;return{setters:[e=>{t=e.x}],execute:function(){
/**
       * @license lucide-react v0.546.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("C",t("clock",[["path",{d:"M12 6v6l4 2",key:"mmk7yg"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]))}}});
