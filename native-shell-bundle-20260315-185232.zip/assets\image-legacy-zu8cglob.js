System.register(["./index-legacy-BAWxtBaz.js"],function(e,t){"use strict";var r;return{setters:[e=>{r=e.x}],execute:function(){
/**
       * @license lucide-react v0.546.0 - ISC
       *
       * This source code is licensed under the ISC license.
       * See the LICENSE file in the root directory of this source tree.
       */
e("I",r("image",[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}],["circle",{cx:"9",cy:"9",r:"2",key:"af1f0g"}],["path",{d:"m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21",key:"1xmnt7"}]]))}}});
