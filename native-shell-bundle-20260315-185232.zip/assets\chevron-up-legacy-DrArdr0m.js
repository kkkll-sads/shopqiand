System.register(["./index-legacy-BAWxtBaz.js"],function(e,t){"use strict";var r;return{setters:[e=>{r=e.x}],execute:function(){
/**
			 * @license lucide-react v0.546.0 - ISC
			 *
			 * This source code is licensed under the ISC license.
			 * See the LICENSE file in the root directory of this source tree.
			 */
e("C",r("chevron-up",[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]]))}}});
