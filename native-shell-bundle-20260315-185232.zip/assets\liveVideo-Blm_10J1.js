import{x as r,ae as n}from"./index-CVy8E7FG.js";/**
 * @license lucide-react v0.546.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const c=[["path",{d:"M9 9.003a1 1 0 0 1 1.517-.859l4.997 2.997a1 1 0 0 1 0 1.718l-4.997 2.997A1 1 0 0 1 9 14.996z",key:"kmsa83"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]],g=r("circle-play",c);function i(e){return typeof e=="string"?e.trim():""}function s(e){return{description:i(e==null?void 0:e.description),title:i(e==null?void 0:e.title),videoUrl:i(e==null?void 0:e.video_url)}}const f={async getConfig(e){const t=await n.get("/api/liveVideo/config",{signal:e});return s(t)}};export{g as C,f as l};
